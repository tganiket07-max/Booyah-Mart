# BOOYAH MARKET — with Database

The app now saves everything in a real SQLite database (`data/booyah.db`) on the server,
so all users see the same listings, and admin approvals work from any phone.

## Run
    npm install
    npm start          # opens on http://localhost:3000

Settings (environment variables):
- First-time users see a sign-up popup: Telegram username (@username) + Terms of Service & Privacy Policy checkboxes (required)
- `ADMIN_PASSWORD` — admin panel password (default: the old password). Change it!
- `PORT` — default 3000
- `DB_PATH` — database file location (default `data/booyah.db`)

## Database tables
- users — username, VIP / VIP PRO type, expiry date, blocked flag
- listings — every FF ID (pending / approved / rejected / deleted), BMW number, sold flag, screenshots
- plan_requests — membership & buyer escrow purchase requests (pending / approved / rejected)

## Hosting (free options)
Render.com, Railway.app or any VPS: upload this folder, build command `npm install`,
start command `npm start`. On Render add a Persistent Disk and set `DB_PATH=/var/data/booyah.db`
so data is not lost on restart.

If you host the HTML separately, set `const API_BASE='https://your-server-url'` at the top of the script in `public/index.html`.

## Play Store version (Oct 2026)

- Public pages: `/privacy`, `/terms`, `/delete-account`
- Login is locked to one device per username (token in `X-User` / `X-User-Token` headers). Admin can "Reset device lock".
- Reports / blocks, in-app account deletion, deletion requests
- Google Play Billing verification: set `GOOGLE_SERVICE_ACCOUNT_JSON` and `ANDROID_PACKAGE`. Without them, Play payments wait for admin approval.
- Backup: Admin panel → "Download database backup" (or `GET /api/admin/backup`). If you copy the DB by hand, stop the server first or also copy `booyah.db-wal`.
- Full steps: see PLAYSTORE_GUIDE.md
