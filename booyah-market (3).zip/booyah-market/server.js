// BOOYAH MARKET - backend + SQLite database
// Run: npm install && npm start   (default port 3000)
//
// Environment variables
//   PORT                         default 3000
//   ADMIN_PASSWORD               admin panel password (CHANGE IT)
//   DB_PATH                      database file (default data/booyah.db)
//   ANDROID_PACKAGE              Play Store package name (default com.booyahmarket.app)
//   GOOGLE_SERVICE_ACCOUNT_JSON  service-account JSON (text) with access to the Play Developer API.
//                                When set, every Google Play purchase is verified with Google.
//   GOOGLE_SERVICE_ACCOUNT_FILE  ...or a path to that JSON file
//   BILLING_TEST_MODE=1          ONLY for testing without Google verification: trusts the app.
const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Aditi 275203';
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'booyah.db');
const ANDROID_PACKAGE = process.env.ANDROID_PACKAGE || 'com.booyahmarket.app';
const BILLING_TEST_MODE = process.env.BILLING_TEST_MODE === '1';
const DAY_MS = 86400000;

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  user_key    TEXT PRIMARY KEY,
  username    TEXT NOT NULL,
  type        TEXT NOT NULL DEFAULT 'regular',   -- regular | vip | vipro
  expires_at  INTEGER NOT NULL DEFAULT 0,
  blocked     INTEGER NOT NULL DEFAULT 0,
  created_at  INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS listings (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  listing_no  INTEGER UNIQUE,
  user_key    TEXT NOT NULL,
  username    TEXT NOT NULL,
  seller_type TEXT NOT NULL,
  level       TEXT NOT NULL,
  server TEXT, login TEXT, evo TEXT, skins TEXT, pass TEXT,
  price       TEXT NOT NULL,
  contact TEXT, utr TEXT,
  images      TEXT NOT NULL DEFAULT '[]',
  screens     TEXT,
  status      TEXT NOT NULL DEFAULT 'pending',   -- pending | approved | rejected | deleted
  sold        INTEGER NOT NULL DEFAULT 0,
  created_at  INTEGER NOT NULL,
  approved_at INTEGER
);
CREATE TABLE IF NOT EXISTS plan_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_key TEXT NOT NULL, username TEXT NOT NULL,
  type TEXT NOT NULL, name TEXT NOT NULL, price TEXT NOT NULL, duration TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at INTEGER NOT NULL, decided_at INTEGER
);
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  listing_id INTEGER NOT NULL,
  reporter_key TEXT NOT NULL,
  reason TEXT NOT NULL, details TEXT,
  status TEXT NOT NULL DEFAULT 'open',            -- open | dismissed | listing_deleted | seller_blocked
  created_at INTEGER NOT NULL, decided_at INTEGER
);
CREATE TABLE IF NOT EXISTS user_blocks (
  blocker_key TEXT NOT NULL, blocked_key TEXT NOT NULL, created_at INTEGER NOT NULL,
  PRIMARY KEY (blocker_key, blocked_key)
);
CREATE TABLE IF NOT EXISTS deletion_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL, contact TEXT, reason TEXT,
  status TEXT NOT NULL DEFAULT 'open',            -- open | done | rejected
  created_at INTEGER NOT NULL, decided_at INTEGER
);
CREATE TABLE IF NOT EXISTS purchases (
  token_hash TEXT PRIMARY KEY,
  order_id TEXT, product_id TEXT NOT NULL, user_key TEXT NOT NULL,
  verified TEXT NOT NULL,                         -- google | test | unverified
  status TEXT NOT NULL,                           -- granted | pending_admin | rejected
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_listings_status ON listings(status);
CREATE INDEX IF NOT EXISTS idx_plans_status ON plan_requests(status);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
`);
// migrations for older databases
const userCols = db.prepare('PRAGMA table_info(users)').all().map(c => c.name);
const addCol = (c, def) => { if (!userCols.includes(c)) db.exec(`ALTER TABLE users ADD COLUMN ${c} ${def}`); };
addCol('terms_accepted_at', 'INTEGER');
addCol('terms_version', 'TEXT');
addCol('draft', 'TEXT');
addCol('device_hash', 'TEXT');          // one-device lock
addCol('device_bound_at', 'INTEGER');
addCol('listing_credits', 'INTEGER NOT NULL DEFAULT 0');  // paid listing fees via Google Play

// ---------- Google Play products (create the same IDs in Play Console > Monetize > In-app products) ----------
const PRODUCTS = {
  vip_1d:      { kind: 'membership', type: 'vip',   days: 1,   name: 'VIP 1 Day',          price: 49 },
  vip_3d:      { kind: 'membership', type: 'vip',   days: 3,   name: 'VIP 3 Days',         price: 149 },
  vip_5d:      { kind: 'membership', type: 'vip',   days: 5,   name: 'VIP 5 Days',         price: 249 },
  vip_7d:      { kind: 'membership', type: 'vip',   days: 7,   name: 'VIP 7 Days',         price: 599 },
  vip_30d:     { kind: 'membership', type: 'vip',   days: 30,  name: 'VIP 30 Days',        price: 2499 },
  vip_90d:     { kind: 'membership', type: 'vip',   days: 90,  name: 'VIP 90 Days',        price: 3599 },
  vip_365d:    { kind: 'membership', type: 'vip',   days: 365, name: 'VIP 365 Days',       price: 4799 },
  vippro_90d:  { kind: 'membership', type: 'vipro', days: 90,  name: 'VIP PRO 90 Days',    price: 5999 },
  vippro_365d: { kind: 'membership', type: 'vipro', days: 365, name: 'VIP PRO 365 Days',   price: 11999 },
  listing_fee: { kind: 'listing_fee',                         name: 'Listing Fee',        price: 25 },
  buyer_escrow:{ kind: 'escrow',                              name: 'Buyer Safety Escrow', price: 99 },
};

// ---------- helpers ----------
const userKey = v => String(v || '').trim().toLowerCase().replace(/^@/, '') || 'unknownuser';
const now = () => Date.now();
const sha = v => crypto.createHash('sha256').update(String(v)).digest('hex');
const clip = (v, n = 500) => String(v ?? '').slice(0, n);
const TG_RE = /^@[A-Za-z][A-Za-z0-9_]{4,31}$/;

function findUser(name) {
  const u = db.prepare('SELECT * FROM users WHERE user_key=?').get(userKey(name));
  if (u && u.expires_at > 0 && u.expires_at <= now()) {
    db.prepare("UPDATE users SET type='regular', expires_at=0 WHERE user_key=?").run(u.user_key);
    u.type = 'regular'; u.expires_at = 0;
  }
  return u;
}
function profileOut(u) {
  if (!u) return { username: null, type: 'regular', days: 0, expiresAt: 0, blocked: false, exists: false };
  const days = u.expires_at > 0 ? Math.max(0, Math.ceil((u.expires_at - now()) / DAY_MS)) : 0;
  return { username: u.username, type: u.type, days, expiresAt: u.expires_at, blocked: !!u.blocked,
    exists: true, listingCredits: u.listing_credits || 0, deviceLocked: !!u.device_hash };
}
function setMembership(name, type, days) {
  const u = findUser(name); if (!u) return null;
  if (type === 'regular') db.prepare("UPDATE users SET type='regular', expires_at=0 WHERE user_key=?").run(u.user_key);
  else {
    // extend if the same plan is still active
    const base = (u.type === type && u.expires_at > now()) ? u.expires_at : now();
    db.prepare('UPDATE users SET type=?, expires_at=? WHERE user_key=?').run(type, base + Number(days) * DAY_MS, u.user_key);
  }
  return profileOut(findUser(name));
}
const nextListingNo = () => db.prepare('SELECT COALESCE(MAX(listing_no),0) m FROM listings').get().m + 1;
function listingPublic(r) {
  return { listingNo: r.listing_no, level: r.level, server: r.server, login: r.login, evo: r.evo,
    skins: r.skins, pass: r.pass, price: r.price, images: JSON.parse(r.images || '[]'),
    screens: r.screens, sold: !!r.sold, sellerType: r.seller_type };
}
function listingAdmin(r) {
  return { ...listingPublic(r), id: r.id, user: r.username, type: r.seller_type, contact: r.contact,
    utr: r.utr, status: r.status, createdAt: r.created_at };
}
function deleteUserCompletely(key) {
  const tx = db.transaction(k => {
    db.prepare("UPDATE listings SET status='deleted', images='[]', contact=NULL, utr=NULL WHERE user_key=? AND status IN ('pending','approved','rejected')").run(k);
    db.prepare("UPDATE plan_requests SET status='rejected', decided_at=? WHERE user_key=? AND status='pending'").run(now(), k);
    db.prepare('DELETE FROM user_blocks WHERE blocker_key=? OR blocked_key=?').run(k, k);
    db.prepare('DELETE FROM users WHERE user_key=?').run(k);
  });
  tx(key);
}

// ---------- Google Play verification (no extra packages) ----------
let gToken = { value: null, exp: 0 };
function serviceAccount() {
  try {
    if (process.env.GOOGLE_SERVICE_ACCOUNT_JSON) return JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_JSON);
    if (process.env.GOOGLE_SERVICE_ACCOUNT_FILE) return JSON.parse(fs.readFileSync(process.env.GOOGLE_SERVICE_ACCOUNT_FILE, 'utf8'));
  } catch (e) { console.error('Service account JSON invalid', e.message); }
  return null;
}
async function googleAccessToken(sa) {
  if (gToken.value && gToken.exp > now() + 60000) return gToken.value;
  const b64 = o => Buffer.from(JSON.stringify(o)).toString('base64url');
  const iat = Math.floor(now() / 1000);
  const unsigned = b64({ alg: 'RS256', typ: 'JWT' }) + '.' + b64({
    iss: sa.client_email, scope: 'https://www.googleapis.com/auth/androidpublisher',
    aud: 'https://oauth2.googleapis.com/token', iat, exp: iat + 3600 });
  const sig = crypto.createSign('RSA-SHA256').update(unsigned).sign(sa.private_key).toString('base64url');
  const r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=' + unsigned + '.' + sig });
  const j = await r.json();
  if (!j.access_token) throw new Error('Google auth failed: ' + JSON.stringify(j));
  gToken = { value: j.access_token, exp: now() + (j.expires_in || 3600) * 1000 };
  return gToken.value;
}
async function verifyWithGoogle(productId, token) {
  const sa = serviceAccount();
  if (!sa) return { mode: BILLING_TEST_MODE ? 'test' : 'unverified' };
  const at = await googleAccessToken(sa);
  const url = `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${encodeURIComponent(ANDROID_PACKAGE)}/purchases/products/${encodeURIComponent(productId)}/tokens/${encodeURIComponent(token)}`;
  const r = await fetch(url, { headers: { Authorization: 'Bearer ' + at } });
  const j = await r.json();
  if (!r.ok) throw new Error('Google verify failed: ' + (j.error && j.error.message || r.status));
  // purchaseState: 0 purchased, 1 canceled, 2 pending
  return { mode: 'google', ok: j.purchaseState === 0, pending: j.purchaseState === 2, data: j };
}

// ---------- app ----------
const app = express();
app.use(express.json({ limit: '30mb' }));
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Admin-Password, X-User, X-User-Token');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

const requireAdmin = (req, res, next) =>
  req.get('X-Admin-Password') === ADMIN_PASSWORD ? next() : res.status(401).json({ error: 'Wrong admin password' });

// user auth: username + secret device token (one account = one mobile)
function authUser(req) {
  const name = req.get('X-User'), token = req.get('X-User-Token');
  if (!name || !token) return null;
  const u = findUser(name);
  if (!u || !u.device_hash || u.device_hash !== sha(token)) return null;
  return u;
}
function requireUser(req, res, next) {
  const u = authUser(req);
  if (!u) return res.status(401).json({ error: 'Session expired. Please login again.', code: 'AUTH' });
  if (u.blocked) return res.status(403).json({ error: 'Your account is blocked. Contact support.' });
  if (!u.terms_accepted_at) return res.status(403).json({ error: 'Please accept the Terms first' });
  req.user = u; next();
}

// Public
app.get('/api/health', (req, res) => res.json({ ok: true }));

app.post('/api/register', (req, res) => {
  const b = req.body || {};
  let name = String(b.username || '').trim().replace(/\s+/g, '');
  if (name && name[0] !== '@') name = '@' + name;
  if (!TG_RE.test(name)) return res.status(400).json({ error: 'Enter a valid Telegram username, e.g. @username' });
  if (b.acceptedTerms !== true) return res.status(400).json({ error: 'Please accept Terms of Service and Privacy Policy' });
  const k = userKey(name);
  let u = db.prepare('SELECT * FROM users WHERE user_key=?').get(k);
  if (u && u.blocked) return res.status(403).json({ error: 'This account is blocked. Contact support.' });
  const isNew = !u;
  if (isNew) db.prepare('INSERT INTO users(user_key,username,created_at) VALUES(?,?,?)').run(k, name, now());
  u = db.prepare('SELECT * FROM users WHERE user_key=?').get(k);
  let token = String(b.deviceToken || '');
  if (u.device_hash) {
    if (!token || sha(token) !== u.device_hash)
      return res.status(409).json({ code: 'DEVICE_LOCKED',
        error: 'Yeh username pehle se kisi aur mobile par login hai. Wahan se account delete karne ke baad hi yahan login hoga. Madad ke liye Telegram par @BOOYAHMARKET07 se sampark karein.' });
  } else {
    token = crypto.randomBytes(24).toString('hex');
    db.prepare('UPDATE users SET device_hash=?, device_bound_at=? WHERE user_key=?').run(sha(token), now(), k);
  }
  db.prepare('UPDATE users SET terms_accepted_at=?, terms_version=? WHERE user_key=?').run(now(), clip(b.termsVersion, 20), k);
  res.json({ ...profileOut(findUser(name)), isNew, token });
});

app.get('/api/users/:name', (req, res) => res.json(profileOut(findUser(req.params.name))));

// in-app account deletion (frees the username for any device)
app.delete('/api/account', requireUser, (req, res) => {
  deleteUserCompletely(req.user.user_key);
  res.json({ ok: true });
});
// web deletion request (for people who no longer have the app/phone)
app.post('/api/account/delete-request', (req, res) => {
  const b = req.body || {};
  let name = String(b.username || '').trim();
  if (name && name[0] !== '@') name = '@' + name;
  if (!TG_RE.test(name)) return res.status(400).json({ error: 'Enter your Telegram username, e.g. @username' });
  const info = db.prepare('INSERT INTO deletion_requests(username,contact,reason,created_at) VALUES(?,?,?,?)')
    .run(name, clip(b.contact, 100), clip(b.reason, 500), now());
  res.json({ ok: true, id: info.lastInsertRowid });
});

app.get('/api/drafts/me', requireUser, (req, res) => res.json(req.user.draft ? JSON.parse(req.user.draft) : {}));
app.post('/api/drafts/me', requireUser, (req, res) => {
  const d = {};
  for (const [k, v] of Object.entries(req.body || {}).slice(0, 20)) d[clip(k, 20)] = clip(v, 2000);
  db.prepare('UPDATE users SET draft=? WHERE user_key=?').run(Object.keys(d).length ? JSON.stringify(d) : null, req.user.user_key);
  res.json({ ok: true });
});

app.get('/api/listings', (req, res) => {
  const viewer = authUser(req);
  let rows = db.prepare("SELECT * FROM listings WHERE status='approved' ORDER BY listing_no DESC").all();
  if (viewer) {
    const blocked = new Set(db.prepare('SELECT blocked_key FROM user_blocks WHERE blocker_key=?').all(viewer.user_key).map(r => r.blocked_key));
    if (blocked.size) rows = rows.filter(r => !blocked.has(r.user_key));
  }
  res.json(rows.map(listingPublic));
});

app.post('/api/listings', requireUser, (req, res) => {
  const b = req.body || {}, u = req.user;
  if (!b.level || !b.price) return res.status(400).json({ error: 'Level and price are required' });
  const isPro = u.type === 'vipro';
  const usePlayCredit = !isPro && b.payMethod === 'play';
  if (usePlayCredit && !(u.listing_credits > 0)) return res.status(402).json({ error: 'Please pay the listing fee with Google Play first' });
  if (!isPro && !usePlayCredit && !String(b.utr || '').trim()) return res.status(400).json({ error: 'Enter transaction UTR after payment' });
  const images = Array.isArray(b.images) ? b.images.filter(x => typeof x === 'string' && x.startsWith('data:image/')).slice(0, 10) : [];
  const status = isPro ? 'approved' : 'pending';
  const listingNo = isPro ? nextListingNo() : null;
  const utr = usePlayCredit ? 'GOOGLE PLAY (listing fee paid)' : clip(b.utr, 100);
  const tx = db.transaction(() => {
    if (usePlayCredit) db.prepare('UPDATE users SET listing_credits=listing_credits-1 WHERE user_key=? AND listing_credits>0').run(u.user_key);
    return db.prepare(`INSERT INTO listings(listing_no,user_key,username,seller_type,level,server,login,evo,skins,pass,price,contact,utr,images,screens,status,created_at,approved_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(listingNo, u.user_key, u.username, u.type, clip(b.level), clip(b.server), clip(b.login),
      clip(b.evo), clip(b.skins), clip(b.pass), clip(b.price, 20), clip(b.contact), utr, JSON.stringify(images), clip(b.screens, 2000),
      status, now(), isPro ? now() : null);
  });
  const info = tx();
  res.json({ id: info.lastInsertRowid, status, listingNo });
});

app.post('/api/plan-requests', requireUser, (req, res) => {
  const b = req.body || {}, u = req.user;
  if (!b.name) return res.status(400).json({ error: 'Missing plan details' });
  const info = db.prepare('INSERT INTO plan_requests(user_key,username,type,name,price,duration,created_at) VALUES(?,?,?,?,?,?,?)')
    .run(u.user_key, u.username, clip(b.type, 20), clip(b.name, 100), clip(b.price, 20), clip(b.duration, 20), now());
  res.json({ id: info.lastInsertRowid, status: 'pending' });
});

// Report & block (Google Play UGC policy)
const REPORT_REASONS = ['Fake / scam listing', 'Stolen or hacked ID', 'Wrong details or screenshots', 'Offensive content', 'Spam', 'Other'];
app.post('/api/reports', requireUser, (req, res) => {
  const b = req.body || {};
  const l = db.prepare("SELECT id FROM listings WHERE listing_no=? AND status='approved'").get(Number(b.listingNo));
  if (!l) return res.status(404).json({ error: 'Listing not found' });
  const reason = REPORT_REASONS.includes(b.reason) ? b.reason : 'Other';
  const dup = db.prepare("SELECT id FROM reports WHERE listing_id=? AND reporter_key=? AND status='open'").get(l.id, req.user.user_key);
  if (dup) return res.json({ ok: true, duplicate: true });
  db.prepare('INSERT INTO reports(listing_id,reporter_key,reason,details,created_at) VALUES(?,?,?,?,?)')
    .run(l.id, req.user.user_key, reason, clip(b.details, 500), now());
  res.json({ ok: true });
});
app.post('/api/blocks', requireUser, (req, res) => {
  const l = db.prepare('SELECT user_key FROM listings WHERE listing_no=?').get(Number((req.body || {}).listingNo));
  if (!l) return res.status(404).json({ error: 'Listing not found' });
  if (l.user_key === req.user.user_key) return res.status(400).json({ error: 'This is your own listing' });
  db.prepare('INSERT OR IGNORE INTO user_blocks(blocker_key,blocked_key,created_at) VALUES(?,?,?)').run(req.user.user_key, l.user_key, now());
  res.json({ ok: true });
});
app.get('/api/blocks', requireUser, (req, res) =>
  res.json({ count: db.prepare('SELECT COUNT(*) n FROM user_blocks WHERE blocker_key=?').get(req.user.user_key).n }));
app.delete('/api/blocks', requireUser, (req, res) => {
  db.prepare('DELETE FROM user_blocks WHERE blocker_key=?').run(req.user.user_key);
  res.json({ ok: true });
});

// Google Play Billing
app.get('/api/billing/products', (req, res) => res.json(PRODUCTS));
app.post('/api/billing/verify', requireUser, async (req, res) => {
  const b = req.body || {}, u = req.user;
  const p = PRODUCTS[b.productId];
  if (!p || !b.purchaseToken) return res.status(400).json({ error: 'Invalid purchase' });
  const th = sha(b.purchaseToken);
  const seen = db.prepare('SELECT * FROM purchases WHERE token_hash=?').get(th);
  if (seen) {
    if (seen.user_key !== u.user_key) return res.status(409).json({ error: 'Purchase already used' });
    return res.json({ ok: true, already: true, status: seen.status, consume: seen.status !== 'rejected', profile: profileOut(findUser(u.username)) });
  }
  let v;
  try { v = await verifyWithGoogle(b.productId, b.purchaseToken); }
  catch (e) { console.error(e); return res.status(502).json({ error: 'Could not verify purchase right now, it will retry automatically.' }); }
  if (v.mode === 'google' && v.pending) return res.json({ ok: false, pending: true, consume: false });
  if (v.mode === 'google' && !v.ok) {
    db.prepare('INSERT INTO purchases VALUES(?,?,?,?,?,?,?)').run(th, clip(b.orderId, 100), b.productId, u.user_key, 'google', 'rejected', now());
    return res.status(400).json({ error: 'Purchase not valid', consume: false });
  }
  const trusted = v.mode === 'google' || v.mode === 'test';
  const tx = db.transaction(() => {
    db.prepare('INSERT INTO purchases VALUES(?,?,?,?,?,?,?)').run(th, clip(b.orderId, 100), b.productId, u.user_key, v.mode, trusted ? 'granted' : 'pending_admin', now());
    const label = p.name + ' (Google Play' + (b.orderId ? ' ' + clip(b.orderId, 60) : '') + ')';
    if (!trusted) {
      // no Google verification configured -> admin must approve in panel
      const type = p.kind === 'membership' ? (p.type === 'vipro' ? 'VIP PRO' : 'VIP') : (p.kind === 'escrow' ? 'BUYER' : 'LISTING FEE');
      db.prepare('INSERT INTO plan_requests(user_key,username,type,name,price,duration,created_at) VALUES(?,?,?,?,?,?,?)')
        .run(u.user_key, u.username, type, label, String(p.price), String(p.days || (p.kind === 'escrow' ? 'single' : 'fee')), now());
      return;
    }
    if (p.kind === 'membership') setMembership(u.username, p.type, p.days);
    else if (p.kind === 'listing_fee') db.prepare('UPDATE users SET listing_credits=listing_credits+1 WHERE user_key=?').run(u.user_key);
    else if (p.kind === 'escrow') db.prepare("INSERT INTO plan_requests(user_key,username,type,name,price,duration,status,created_at) VALUES(?,?,?,?,?,?,'pending',?)")
      .run(u.user_key, u.username, 'BUYER', label + ' — PAID', String(p.price), 'single', now());
  });
  tx();
  res.json({ ok: true, status: trusted ? 'granted' : 'pending_admin', consume: true, profile: profileOut(findUser(u.username)) });
});

// Admin
app.post('/api/admin/login', requireAdmin, (req, res) => res.json({ ok: true }));

app.get('/api/admin/requests', requireAdmin, (req, res) => {
  const ids = db.prepare("SELECT * FROM listings WHERE status='pending' ORDER BY created_at").all().map(listingAdmin);
  const plans = db.prepare("SELECT * FROM plan_requests WHERE status='pending' ORDER BY created_at").all()
    .map(r => ({ id: r.id, user: r.username, type: r.type, name: r.name, price: r.price, duration: r.duration, createdAt: r.created_at }));
  res.json({ idRequests: ids, planRequests: plans });
});

app.post('/api/admin/id-requests/:id/:action', requireAdmin, (req, res) => {
  const r = db.prepare("SELECT * FROM listings WHERE id=? AND status='pending'").get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Request not found' });
  if (req.params.action === 'approve') {
    const no = nextListingNo();
    db.prepare("UPDATE listings SET status='approved', listing_no=?, approved_at=? WHERE id=?").run(no, now(), r.id);
    return res.json({ ok: true, listingNo: no });
  }
  if (req.params.action === 'reject') { db.prepare("UPDATE listings SET status='rejected' WHERE id=?").run(r.id); return res.json({ ok: true }); }
  res.status(400).json({ error: 'Unknown action' });
});

app.post('/api/admin/plan-requests/:id/:action', requireAdmin, (req, res) => {
  const r = db.prepare("SELECT * FROM plan_requests WHERE id=? AND status='pending'").get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Request not found' });
  if (req.params.action === 'approve') {
    let profile = null;
    const days = Number(r.duration);
    if (findUser(r.username)) {
      if (Number.isFinite(days) && days > 0 && (r.type === 'VIP' || r.type === 'VIP PRO'))
        profile = setMembership(r.username, r.type === 'VIP PRO' ? 'vipro' : 'vip', days);
      if (r.type === 'LISTING FEE') db.prepare('UPDATE users SET listing_credits=listing_credits+1 WHERE user_key=?').run(r.user_key);
    }
    db.prepare("UPDATE plan_requests SET status='approved', decided_at=? WHERE id=?").run(now(), r.id);
    return res.json({ ok: true, user: r.username, profile });
  }
  if (req.params.action === 'reject') { db.prepare("UPDATE plan_requests SET status='rejected', decided_at=? WHERE id=?").run(now(), r.id); return res.json({ ok: true }); }
  res.status(400).json({ error: 'Unknown action' });
});

app.get('/api/admin/users/:name', requireAdmin, (req, res) => res.json(profileOut(findUser(req.params.name))));
app.post('/api/admin/users/:name/membership', requireAdmin, (req, res) => {
  const { type, days } = req.body || {};
  if (!['regular', 'vip', 'vipro'].includes(type)) return res.status(400).json({ error: 'Bad type' });
  if (!findUser(req.params.name)) return res.status(404).json({ error: 'User not found' });
  res.json(setMembership(req.params.name, type, Number(days) || 0));
});
app.post('/api/admin/users/:name/block', requireAdmin, (req, res) => {
  const u = findUser(req.params.name); if (!u) return res.status(404).json({ error: 'User not found' });
  const blocked = req.body && req.body.blocked === false ? 0 : 1;
  db.prepare('UPDATE users SET blocked=? WHERE user_key=?').run(blocked, u.user_key);
  res.json(profileOut(findUser(req.params.name)));
});
app.post('/api/admin/users/:name/reset-device', requireAdmin, (req, res) => {
  const u = findUser(req.params.name); if (!u) return res.status(404).json({ error: 'User not found' });
  db.prepare('UPDATE users SET device_hash=NULL, device_bound_at=NULL WHERE user_key=?').run(u.user_key);
  res.json(profileOut(findUser(req.params.name)));
});
app.delete('/api/admin/users/:name', requireAdmin, (req, res) => {
  const u = findUser(req.params.name); if (!u) return res.status(404).json({ error: 'User not found' });
  deleteUserCompletely(u.user_key);
  db.prepare("UPDATE deletion_requests SET status='done', decided_at=? WHERE lower(username)=lower(?) AND status='open'").run(now(), u.username);
  res.json({ ok: true });
});

app.post('/api/admin/listings/:no/sold', requireAdmin, (req, res) => {
  const info = db.prepare("UPDATE listings SET sold=1 WHERE listing_no=? AND status='approved'").run(req.params.no);
  info.changes ? res.json({ ok: true }) : res.status(404).json({ error: 'BMW' + req.params.no + ' nahi mila' });
});
app.delete('/api/admin/listings/:no', requireAdmin, (req, res) => {
  const info = db.prepare("UPDATE listings SET status='deleted' WHERE listing_no=? AND status='approved'").run(req.params.no);
  info.changes ? res.json({ ok: true }) : res.status(404).json({ error: 'BMW' + req.params.no + ' nahi mila' });
});

app.get('/api/admin/reports', requireAdmin, (req, res) => {
  const rows = db.prepare(`SELECT r.*, l.listing_no, l.level, l.price, l.username seller, l.status lstatus
    FROM reports r JOIN listings l ON l.id=r.listing_id WHERE r.status='open' ORDER BY r.created_at`).all();
  res.json(rows.map(r => ({ id: r.id, listingNo: r.listing_no, level: r.level, price: r.price, seller: r.seller,
    reason: r.reason, details: r.details, listingStatus: r.lstatus, createdAt: r.created_at })));
});
app.post('/api/admin/reports/:id/:action', requireAdmin, (req, res) => {
  const r = db.prepare("SELECT r.*, l.user_key seller_key FROM reports r JOIN listings l ON l.id=r.listing_id WHERE r.id=?").get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Report not found' });
  const a = req.params.action;
  if (a === 'dismiss') db.prepare("UPDATE reports SET status='dismissed', decided_at=? WHERE id=?").run(now(), r.id);
  else if (a === 'delete-listing') {
    db.prepare("UPDATE listings SET status='deleted' WHERE id=?").run(r.listing_id);
    db.prepare("UPDATE reports SET status='listing_deleted', decided_at=? WHERE listing_id=? AND status='open'").run(now(), r.listing_id);
  } else if (a === 'block-seller') {
    db.prepare('UPDATE users SET blocked=1 WHERE user_key=?').run(r.seller_key);
    db.prepare("UPDATE listings SET status='deleted' WHERE user_key=? AND status IN ('approved','pending')").run(r.seller_key);
    db.prepare("UPDATE reports SET status='seller_blocked', decided_at=? WHERE listing_id IN (SELECT id FROM listings WHERE user_key=?) AND status='open'").run(now(), r.seller_key);
  } else return res.status(400).json({ error: 'Unknown action' });
  res.json({ ok: true });
});

app.get('/api/admin/deletion-requests', requireAdmin, (req, res) =>
  res.json(db.prepare("SELECT * FROM deletion_requests WHERE status='open' ORDER BY created_at").all()));
app.post('/api/admin/deletion-requests/:id/:action', requireAdmin, (req, res) => {
  const r = db.prepare("SELECT * FROM deletion_requests WHERE id=? AND status='open'").get(req.params.id);
  if (!r) return res.status(404).json({ error: 'Request not found' });
  if (req.params.action === 'delete') {
    const u = findUser(r.username); if (u) deleteUserCompletely(u.user_key);
    db.prepare("UPDATE deletion_requests SET status='done', decided_at=? WHERE id=?").run(now(), r.id);
  } else if (req.params.action === 'reject') db.prepare("UPDATE deletion_requests SET status='rejected', decided_at=? WHERE id=?").run(now(), r.id);
  else return res.status(400).json({ error: 'Unknown action' });
  res.json({ ok: true });
});

// consistent database backup download (admin only)
app.get('/api/admin/backup', requireAdmin, async (req, res) => {
  const file = path.join(path.dirname(DB_PATH), 'backup-' + Date.now() + '.db');
  try {
    await db.backup(file);
    res.download(file, 'booyah-backup-' + new Date().toISOString().slice(0, 10) + '.db', () => fs.unlink(file, () => {}));
  } catch (e) { res.status(500).json({ error: 'Backup failed: ' + e.message }); }
});

app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const c = s => db.prepare(s).get().n;
  res.json({
    users: c('SELECT COUNT(*) n FROM users'),
    liveListings: c("SELECT COUNT(*) n FROM listings WHERE status='approved' AND sold=0"),
    soldListings: c("SELECT COUNT(*) n FROM listings WHERE status='approved' AND sold=1"),
    pendingIds: c("SELECT COUNT(*) n FROM listings WHERE status='pending'"),
    pendingPlans: c("SELECT COUNT(*) n FROM plan_requests WHERE status='pending'"),
    openReports: c("SELECT COUNT(*) n FROM reports WHERE status='open'"),
    deletionRequests: c("SELECT COUNT(*) n FROM deletion_requests WHERE status='open'"),
    billing: serviceAccount() ? 'google-verified' : (BILLING_TEST_MODE ? 'TEST MODE' : 'admin-approval'),
  });
});

// Public pages: /privacy, /terms, /delete-account
app.get(['/privacy', '/privacy-policy'], (req, res) => res.sendFile(path.join(__dirname, 'public', 'privacy.html')));
app.get('/terms', (req, res) => res.sendFile(path.join(__dirname, 'public', 'terms.html')));
app.get('/delete-account', (req, res) => res.sendFile(path.join(__dirname, 'public', 'delete-account.html')));
app.use(express.static(path.join(__dirname, 'public')));

// write everything into the main DB file regularly and on shutdown
setInterval(() => { try { db.pragma('wal_checkpoint(PASSIVE)'); } catch (e) {} }, 60000);
function shutdown() { try { db.pragma('wal_checkpoint(TRUNCATE)'); db.close(); } catch (e) {} process.exit(0); }
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

app.listen(PORT, () => console.log('BOOYAH MARKET running on http://localhost:' + PORT + '  DB: ' + DB_PATH +
  '  Billing: ' + (serviceAccount() ? 'Google verified' : BILLING_TEST_MODE ? 'TEST MODE' : 'admin approval')));
