# BOOYAH MARKET — Play Store Guide (Hinglish)

Is guide me step-by-step bataya gaya hai ki app ko Google Play Store par kaise live karna hai.

## Kya-kya bana hai

| Cheez | File / Jagah |
|---|---|
| Website + Database server | `booyah-market.zip` (Node.js + SQLite) |
| Android app ka source code | `booyah-android.zip` (Java, package `com.booyahmarket.app`) |
| Test ke liye APK | `BooyahMarket-debug.apk` |
| Play Store upload file | `app-release.aab` (signed, target API 36) |
| Upload key (bahut zaroori) | `booyah-upload-key.jks` + `keystore.properties` |
| Play Store icon 512x512 | `playstore-icon-512.png` |

Naye features:
- Image upload: Gallery + Camera, Android app ke andar kaam karta hai
- Account delete: app me (Support → My Account → Delete my account) + web page `/delete-account`
- Listing par Report aur Block seller; admin panel me Reports aur Deletion Requests
- Public pages: `/privacy`, `/terms`, `/delete-account`
- Ek username ek hi mobile me chalega, jab tak wahan se account delete na ho
- Google Play Billing: VIP plans, ₹25 listing fee, ₹99 buyer escrow
- Admin panel me "Reset device lock" (agar user ne app uninstall kar diya) aur "Download database backup"

## Step 1 — Server ko online host karo (sabse pehle)

APK tabhi chalega jab server internet par HTTPS URL ke saath live ho. Sasta aur aasan option hai Render.com:

1. GitHub par naya repo banao aur `booyah-market.zip` ka content upload karo.
2. Render.com par jao → New → Web Service → woh repo chuno.
3. Build command: `npm install`, Start command: `node server.js`.
4. Disk add karo (Persistent Disk, 1 GB), mount path `/data`. Iske bina har restart par data mit jayega.
5. Environment variables:
   - `DB_PATH` = `/data/booyah.db`
   - `ADMIN_PASSWORD` = apna naya strong password (purana "Aditi 275203" zaroor badlo)
   - `ANDROID_PACKAGE` = `com.booyahmarket.app`
   - `GOOGLE_SERVICE_ACCOUNT_JSON` = (Step 4 me milega)
6. Deploy ke baad URL milega, jaise `https://booyah-market.onrender.com`. Check karo ki `/privacy` aur `/delete-account` khul rahe hain.

Har hafte admin panel se "Download database backup" karke file safe rakho.

## Step 2 — Android app me server URL daalo

`booyah-android/app/build.gradle` me ye line badlo:

```
def SERVER_URL = project.findProperty('SERVER_URL') ?: 'https://YOUR-SERVER-URL.onrender.com'
```

Phir build karo (Android Studio, ya command line):

```
./gradlew bundleRelease      # Play Store ke liye: app/build/outputs/bundle/release/app-release.aab
./gradlew assembleDebug      # test APK
```

Jo debug APK abhi diya gaya hai, woh pehli baar khulne par server URL poochta hai, isliye usse bina rebuild kiye bhi test kar sakte ho.

## Step 3 — Play Console me app banao

1. play.google.com/console → Developer account ($25 ek baar). Naye personal accounts ko production se pehle 12 testers ke saath 14 din closed testing karni padti hai.
2. Create app → Name "BOOYAH MARKET", App, Free.
3. App signing: Play App Signing ON rakho, aur `app-release.aab` upload karo (pehle Internal testing me).
4. In-app products banao (Monetize → Products → In-app products). Product ID bilkul yahi hone chahiye:

| Product ID | Naam | Price (₹) |
|---|---|---|
| vip_1d | VIP 1 Day | 49 |
| vip_3d | VIP 3 Days | 149 |
| vip_5d | VIP 5 Days | 249 |
| vip_7d | VIP 7 Days | 599 |
| vip_30d | VIP 30 Days | 2499 |
| vip_90d | VIP 90 Days | 3599 |
| vip_365d | VIP 365 Days | 4799 |
| vippro_90d | VIP PRO 90 Days | 5999 |
| vippro_365d | VIP PRO 365 Days | 11999 |
| listing_fee | Listing Fee | 25 |
| buyer_escrow | Buyer Safety Escrow | 99 |

Sab "consumable" ki tarah kaam karte hain (app khud consume karti hai, isliye dobara khareed sakte hain).

## Step 4 — Payment verification (service account)

Server har Google Play payment ko Google se verify karta hai.

1. Google Cloud Console → naya project → "Google Play Android Developer API" enable karo.
2. IAM → Service Accounts → naya account → JSON key download karo.
3. Play Console → Users and permissions → Invite user → us service account ka email → permission: "View financial data" aur "Manage orders".
4. JSON file ka poora text Render me `GOOGLE_SERVICE_ACCOUNT_JSON` me paste karo.
5. Admin panel me Billing "google-verified" dikhna chahiye.

Jab tak service account nahi lagta, har Play payment admin panel me "pending" request ban kar aayega aur aapko manually approve karna hoga. `BILLING_TEST_MODE=1` sirf testing ke liye hai; live app me kabhi mat lagana.

Testing ke liye: Play Console → Settings → License testing me apna Gmail daalo, taaki test payment free ho.

## Step 5 — Store listing aur forms

- Privacy policy URL: `https://AAPKA-URL/privacy`
- Account deletion URL (Data safety form me): `https://AAPKA-URL/delete-account`
- Data safety:
  - Collected: User IDs (Telegram username), Photos (listing screenshots), Purchase history, App interactions
  - Shared: koi nahi
  - Encrypted in transit: Haan (HTTPS)
  - Users can request deletion: Haan
- Content rating questionnaire: user-generated content = Haan, users interact = Haan, digital purchases = Haan
- Target audience: 18+ rakho (account trading aur payments ki wajah se)
- App access: reviewers ke liye likho ki login sirf Telegram username se hota hai (koi password nahi), example `@playreviewer`
- Graphics: icon 512x512 (`playstore-icon-512.png`), feature graphic 1024x500, kam se kam 2 phone screenshots

## Step 6 — Keystore ko safe rakho

`booyah-upload-key.jks` aur `keystore.properties` (password isi me hai) ko Google Drive aur pen drive dono me backup karo. Ye kho gaye to app ka update upload karne ke liye Google se key reset karwana padega. Ye files kisi ko mat bhejo.

## Zaroori risk (dhyan se padho)

- Garena ke Terms of Service Free Fire account bechne/kharidne ki ijaazat nahi dete. Google Play aisi apps ko IP/impersonation ya "account trading" policy ke tahat reject ya remove kar sakta hai. Store listing me Garena ka logo ya official artwork use mat karo, aur "Not affiliated with Garena" likho.
- Account ke liye real-money trade karne se Play review strict hoga. Rejection aaye to reason padh kar humein batao.
- Escrow (₹99) ek service hai. Agar Google kahe ki ye "physical/peer-to-peer" payment hai, to wahan Play Billing ki jagah UPI allowed ho sakta hai — review ke baad decide karenge.

## Device lock — user ka mobile kho gaya ya app uninstall ho gaya

Admin panel → username search → "Reset device lock". Uske baad user naye mobile me usi username se login kar sakta hai. Pehle Telegram par confirm kar lena ki woh asli user hi hai.
